package com.capgemini.service;

import com.capgemini.model.Merchant;

public interface IMerchantService {
	public Merchant addMerchant(Merchant merchant);
}
