package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.model.Merchant;
import com.capgemini.repository.IMerchantRepo;
@Component("MerchantServices")
public class MerchantServiceImpl implements IMerchantService {

	@Autowired(required = true)
	IMerchantRepo repo;
	
	@Override
	public Merchant addMerchant(Merchant merchant) {
	
		return repo.save(merchant);
	}

}
