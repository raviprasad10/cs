package com.capgemini.model;

public class MerchantOrders {
	int orderId;
	
}
